"""Testes de caixa-preta. Python 3 + GCC; nenhuma dependencia externa."""
from pathlib import Path
import subprocess, tempfile, json, platform
ROOT = Path(__file__).resolve().parents[1]

def cadastro(c=101, escola='Escola Horizonte', tema='Saude bucal', prevista=40, situacao=1, efetiva=0, data='10/10/2026'):
    valores=[1,c,escola,tema,data,'Turmas do 6 ano','Equipe IntegraPSE',prevista,situacao]
    if situacao==2: valores.append(efetiva)
    return '\n'.join(map(str,valores))+'\n'

def main():
    resultados=[]
    with tempfile.TemporaryDirectory() as pasta:
        exe=Path(pasta)/'pse'
        comando=['gcc','-std=c11','-Wall','-Wextra','-Wpedantic','-Werror',str(ROOT/'src/main.c'),'-o',str(exe)]
        subprocess.run(comando,check=True,capture_output=True,text=True)
        def teste(id, descricao, entrada, esperados, ausentes=()):
            r=subprocess.run([str(exe)],input=entrada,capture_output=True,text=True,timeout=5)
            ok=r.returncode==0 and all(t in r.stdout for t in esperados) and all(t not in r.stdout for t in ausentes)
            resultados.append({'id':id,'cenario':descricao,'resultado':'PASSOU' if ok else 'FALHOU'})
            if not ok: raise AssertionError(f'{id}: {descricao}\n{r.stdout}\n{r.stderr}')
        teste('T01','Base vazia: listar, pesquisar, atualizar e resumir','2\n3\n4\n5\n6\n',['Nenhuma acao cadastrada.','Acoes cadastradas: 0','N/A'])
        teste('T02','Cadastro planejado e listagem completa',cadastro()+'2\n6\n',['Codigo: 101 | Situacao: Planejada','Publico-alvo: Turmas do 6 ano','Previstos: 40 | Efetivos: 0'])
        teste('T03','Cadastro realizado solicita efetivos',cadastro(situacao=2,efetiva=32)+'5\n6\n',['Realizadas: 1','Total de participacoes efetivas: 32','80.00%'])
        teste('T04','Cadastro cancelado zera efetivos',cadastro(situacao=3)+'2\n6\n',['Situacao: Cancelada','Efetivos: 0'])
        segundo=cadastro(102).splitlines(); segundo.insert(1,'101')
        teste('T05','Codigo duplicado exige outro identificador',cadastro()+'\n'.join(segundo)+'\n5\n6\n',['codigo ja cadastrado','Acoes cadastradas: 2'])
        teste('T06','Pesquisa exata por codigo e registro ausente',cadastro()+'3\n1\n101\n3\n1\n999\n6\n',['Encontradas: 1','Nenhuma acao encontrada.'])
        teste('T07','Pesquisa parcial por escola retorna todos os resultados',cadastro()+cadastro(102,escola='Escola Horizonte II')+'3\n2\nhORIZONTE\n6\n',['Encontradas: 2'])
        teste('T08','Pesquisa parcial por tema',cadastro()+'3\n3\nBUCAL\n6\n',['Encontradas: 1'])
        teste('T09','Atualiza para realizada e corrige efetivos',cadastro()+'4\n101\n2\n32\n4\n101\n2\n36\n5\n6\n',['Total de participacoes efetivas: 36','90.00%'])
        teste('T10','Atualizacao de codigo inexistente',cadastro()+'4\n999\n5\n6\n',['Registro inexistente.','Planejadas: 1'])
        teste('T11','Realizada para cancelada e planejada elimina efetivos',cadastro(situacao=2,efetiva=32)+'4\n101\n3\n5\n4\n101\n1\n5\n6\n',['Canceladas: 1','Planejadas: 1','Total de participacoes efetivas: 0'])
        teste('T12','Resumo misto: percentual so das realizadas',cadastro(situacao=2,efetiva=32)+cadastro(102,prevista=20)+cadastro(103,prevista=10,situacao=3)+'5\n6\n',['Planejadas: 1 | Realizadas: 1 | Canceladas: 1','Previstos em todas as acoes: 70','Previstos nas realizadas: 40','80.00%'])
        teste('T13','Previsao zero evita divisao por zero',cadastro(prevista=0,situacao=2,efetiva=5)+'5\n6\n',['Total de participacoes efetivas: 5','N/A'])
        teste('T14','Participacao superior ao previsto permitida',cadastro(prevista=10,situacao=2,efetiva=12)+'5\n6\n',['120.00%'])
        teste('T15','Menu rejeita texto, decimal, lixo e inteiro excessivo','abc\n1.5\n2abc\n9999999999999999999999999\n0\n7\n6\n',['Erro: informe um inteiro','Encerrando o sistema.'])
        s=cadastro().replace('Escola Horizonte\n','\n   \nEscola Horizonte\n').replace('\n40\n1\n','\n-1\n40\n0\n4\n1\n')
        teste('T16','Campos vazios, quantidade negativa e situacao invalida',s+'2\n6\n',['campo obrigatorio vazio','Erro: informe um inteiro','Previstos: 40 | Efetivos: 0'])
        teste('T17','Datas impossiveis e ano nao bissexto',cadastro(data='31/04/2026\n29/02/2026\n29/02/2028')+'2\n6\n',['data invalida','Data prevista: 29/02/2028'])
        teste('T18','Campo longo recusado sem contaminar a proxima entrada',cadastro(escola='X'*101+'\nEscola Horizonte')+'2\n6\n',['texto muito longo','Escola: Escola Horizonte'])
        teste('T19','100 registros aceitos; tentativa 101 bloqueada',''.join(cadastro(c=i) for i in range(1,101))+'1\n5\n6\n',['Limite de armazenamento atingido','Acoes cadastradas: 100'])
        teste('T20','EOF no cadastro encerra sem confirmar','1\n101\n',['Operacao incompleta nao confirmada'],['Sucesso: acao cadastrada'])
        teste('T21','Somas de grandes quantidades sem overflow de int',cadastro(prevista=2147483647,situacao=2,efetiva=2147483647)+cadastro(102,prevista=2147483647,situacao=2,efetiva=2147483647)+'5\n6\n',['Total de participacoes efetivas: 4294967294','100.00%'])
        teste('T22','Limite exato de texto (100 bytes) aceito',cadastro(escola='A'*100)+'2\n6\n',['Escola: '+'A'*100],['texto muito longo'])
        teste('T23','Quantidade efetiva negativa exige correcao',cadastro(situacao=2,efetiva='-3\n32')+'5\n6\n',['Erro: informe um inteiro','Total de participacoes efetivas: 32'])
        teste('T24','Codigo zero ou negativo e submenu invalido',cadastro(c='0\n-1\n101')+'3\n9\n1\n101\n6\n',['Erro: informe um inteiro','Encontradas: 1'])
        teste('T25','Pesquisa vazia e sem correspondencia',cadastro()+'3\n2\n\n   \nInexistente\n6\n',['campo obrigatorio vazio','Nenhuma acao encontrada.'])
        teste('T26','Nova execucao inicia sem os dados da anterior','2\n6\n',['Nenhuma acao cadastrada.'])
        teste('T27','Datas de seculos e formato estrito',cadastro(data='29/02/1900\n1/01/2026\n01/01/0000\n29/02/2000')+'2\n6\n',['data invalida','Data prevista: 29/02/2000'])
        teste('T28','EOF em atualizacao incompleta encerra',cadastro()+'4\n101\n2\n',['Operacao incompleta nao confirmada'],['Sucesso: situacao atualizada'])
    relatorio={'ambiente':platform.platform(),'compilador':subprocess.check_output(['gcc','--version'],text=True).splitlines()[0], 'flags':'-std=c11 -Wall -Wextra -Wpedantic -Werror','total':len(resultados),'testes':resultados}
    (ROOT/'docs/evidencias/testes.json').write_text(json.dumps(relatorio,ensure_ascii=False,indent=2),encoding='utf-8')
    texto='\n'.join(f"{x['id']} | {x['resultado']} | {x['cenario']}" for x in resultados)
    (ROOT/'docs/evidencias/testes.txt').write_text(texto+'\n',encoding='utf-8')
    print(texto); print(f'\n{len(resultados)}/{len(resultados)} testes passaram.')

if __name__=='__main__': main()
