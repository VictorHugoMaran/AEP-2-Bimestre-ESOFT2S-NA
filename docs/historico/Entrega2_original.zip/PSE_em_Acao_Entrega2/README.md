# PSE em Ação

Sistema de Planejamento e Acompanhamento de Ações de Saúde na Escola.

Projeto da **Atividade de Estudo Programada (AEP)**, Engenharia de Software, UniCesumar, ESOFT2S-NA, 2026/2. A IntegraPSE é a equipe intersetorial fictícia atendida pela solução.

## Integrantes

| Nome | R.A. |
| --- | --- |
| Daniel Muniz Gallina | 26008793-2 |
| Murilo Bovo Bonvechio | 26011546-2 |
| Victor Hugo Maran Kalomenconkovas | 26001189-2 |

## Problema e objetivo

As informações das ações coletivas encontram-se dispersas em anotações, formulários e planilhas. O sistema centraliza o registro e o acompanhamento para coordenadores do PSE, profissionais de saúde e representantes pedagógicos. Estudantes são beneficiários indiretos; não têm cadastro individual.

Esta versão implementa o planejamento da primeira entrega: aplicação em C executada em terminal, com informações coletivas e fictícias armazenadas em memória.

## Situação da segunda entrega

- [x] Código funcional, menu e seis requisitos mínimos implementados.
- [x] Compilação sem avisos em Linux/GCC e 28 testes automáticos aprovados.
- [x] Casos de uso, requisitos, fluxogramas e pseudocódigos revisados.
- [x] Manual, evidências de execução e considerações finais.
- [ ] Revisão da equipe e execução no ambiente definido pelo professor.
- [ ] Incorporação dos arquivos ao GitHub da equipe.
- [ ] Vídeo de até sete minutos, com os três integrantes, e link acessível.

**Vídeo: pendente de gravação e inclusão do link.**

Repositório informado na primeira entrega: https://github.com/VictorHugoMaran/AEP-1-Bimestre-ESOFT2S-NA

## Compilação e execução

Abra o terminal na pasta raiz deste pacote. Requer compilador C11 (GCC ou equivalente); o programa só usa a biblioteca padrão de C.

Linux/macOS com GCC disponível:

```bash
gcc -std=c11 -Wall -Wextra -Wpedantic src/main.c -o pse
./pse
```

Windows/PowerShell com GCC/MinGW disponível:

```powershell
gcc -std=c11 -Wall -Wextra -Wpedantic src/main.c -o pse.exe
.\pse.exe
```

Se `gcc` não for reconhecido, configure o compilador usado na disciplina. Os comandos Windows são orientações; a execução foi verificada em Linux. Não é necessário instalar Python para utilizar o sistema.

## Funcionalidades

| Opção | Operação | Requisito |
| --- | --- | --- |
| 1 | Cadastrar código, escola, tema, data, público, responsável, previsão e situação | RF01 |
| 2 | Listar todas as ações e seus campos | RF02 |
| 3 | Pesquisar por código exato ou trecho de escola/tema | RF03 |
| 4 | Atualizar situação e participantes efetivos | RF04 |
| 5 | Resumir situações, previsões, efetivos e percentual | RF05 |
| 6 | Encerrar e descartar os dados da sessão | Controle do menu |

RF06 é transversal: valida códigos, quantidades, campos obrigatórios, datas, opções e limite de armazenamento. Não é uma opção separada no menu.

## Regras desta versão

- Máximo de 100 ações por execução; códigos positivos e únicos.
- Quantidades inteiras de zero até `INT_MAX`; não existe limite artificial na previsão de comparecimento.
- Datas existentes em `DD/MM/AAAA`, ano 0001 a 9999. Não exige data futura.
- Textos com até 100 bytes, sem campos vazios. Acentos podem consumir mais de um byte.
- Situações: 1 planejada, 2 realizada, 3 cancelada.
- Cadastro já realizado também solicita efetivos.
- Ao mudar para planejada ou cancelada, os efetivos são zerados; não há histórico.
- Ao selecionar realizada novamente, é possível corrigir os efetivos.
- Busca textual parcial ignora caixa nas letras ASCII. Acentos devem coincidir.
- Percentual = 100 × efetivos das realizadas / previstos das realizadas. Planejadas e canceladas ficam fora do denominador.
- Denominador zero gera `N/A`; efetivos acima da previsão são aceitos.
- Totais são participações acumuladas, não contagem de estudantes únicos.
- Dados não persistem após sair. EOF encerra sem confirmar uma operação incompleta.

Essas regras detalham pontos abertos da primeira entrega e devem ser revisadas pela equipe.

## Exemplo de demonstração

Cadastre 101: Escola Horizonte; Saude bucal; 10/10/2026; Turmas do 6 ano; Equipe IntegraPSE; 40 previstos; planejada. Liste, pesquise por `horizonte` e atualize para realizada com 32 efetivos.

Cadastre 102 com 20 previstos e situação planejada; cadastre 103 com 10 previstos e situação cancelada. O resumo deverá mostrar 1 planejada, 1 realizada, 1 cancelada, 70 previstos no conjunto, 40 previstos nas realizadas, 32 efetivos e **80,00%** (o programa usa ponto decimal: `80.00%`).

## Testes

Requer Python 3 e GCC apenas para executar os testes:

```bash
python3 tests/testar.py
```

No Windows, pode-se usar `python tests/testar.py`. O script recompila o programa numa pasta temporária e atualiza os resultados em `docs/evidencias/testes.json` e `testes.txt`.

Os 28 cenários cobrem operações, base vazia, duplicidade, entradas inválidas, datas, limite de texto e capacidade, atualização, percentuais, grandes totais e EOF. Os testes não substituem a verificação no ambiente do professor.

## Documentação e estrutura

- [`src/main.c`](src/main.c): código completo.
- [`docs/AEP_2_Entrega_PSE_em_Acao.pdf`](docs/AEP_2_Entrega_PSE_em_Acao.pdf): documento da segunda etapa.
- [`docs/AEP_2_Entrega_PSE_em_Acao.md`](docs/AEP_2_Entrega_PSE_em_Acao.md): conteúdo editável do documento; alterações não regeneram o PDF automaticamente.
- [`docs/AEP_1_Entrega_PSE_em_Acao.pdf`](docs/AEP_1_Entrega_PSE_em_Acao.pdf): primeira entrega preservada.
- [`docs/casos_de_uso.svg`](docs/casos_de_uso.svg): diagrama de casos de uso.
- [`docs/fluxograma_geral.svg`](docs/fluxograma_geral.svg) e [`docs/fluxograma_cadastro.svg`](docs/fluxograma_cadastro.svg): fluxogramas revisados.
- [`docs/roteiro_video.md`](docs/roteiro_video.md): proposta de apresentação em 6min40s.
- [`docs/evidencias/`](docs/evidencias/): imagens renderizadas da saída real do terminal, transcrição e resultados de testes.
- [`tests/testar.py`](tests/testar.py): testes reproduzíveis, sem bibliotecas Python externas.

## Limites éticos e técnicos

Somente dados fictícios e coletivos. Não registrar nomes ou dados clínicos de estudantes, diagnósticos, prontuários ou condições individuais. A aplicação não faz diagnóstico, triagem, prescrição ou recomendação de tratamento. Os campos livres não bloqueiam automaticamente textos inadequados: o operador deve respeitar o escopo.

Não há banco de dados, interface gráfica, aplicação web, autenticação, exclusão ou histórico. Melhorias futuras podem incluir persistência em arquivo, edição de outros campos e filtros por período.

## Antes de entregar

1. Revisar o código e as regras, testar no ambiente da disciplina e compreender a implementação.
2. Incorporar `src/`, `tests/` e a nova documentação ao repositório existente. Preservar os documentos e fluxogramas originais da equipe.
3. Revisar este README antes de substituir o atual; manter informações específicas que não constem do pacote.
4. Gravar o vídeo com os três integrantes, máximo de sete minutos, mostrando o programa funcionando e a relação com requisitos e algoritmos.
5. Inserir o link acessível do vídeo aqui e no documento final, substituindo a pendência da capa.
6. Conferir o GitHub e a entrega individual de cada integrante. O pacote não publica automaticamente no GitHub.

## Documentos-base

- Universidade Cesumar. **AEP 2 Semestre 2026**. Enunciado fornecido.
- Gallina, Bonvechio e Kalomenconkovas. **PSE em Ação — Primeira entrega da AEP**, 2026.
- Imagens do README fornecidas pela equipe. A fundamentação e as referências da primeira etapa permanecem no PDF original em `docs/`.
